package com.example.feedme.models

data class User (val _id: String, val email: String, val password: String)