package com.example.feedme.ui.questionnaire

import androidx.lifecycle.ViewModel

class QuestionnaireViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
